#!/bin/bash

## Autostartup applications

mate-at-properties 

